SELECT * FROM meubd.agencia;
SELECT * FROM meubd.clientes;
SELECT * FROM meubd.conta_bancaria;
SELECT * FROM meubd.conta_corrente;
SELECT * FROM meubd.emails_clientes;
SELECT * FROM meubd.dependentes;
SELECT * FROM meubd.conta_especial;
SELECT * FROM meubd.conta_e_cliente;
SELECT * FROM meubd.endereco_cliente;
SELECT * FROM meubd.funcionario;
SELECT * FROM meubd.poupanca;
SELECT * FROM meubd.telefones_clientes;
SELECT * FROM meubd.transacao;

